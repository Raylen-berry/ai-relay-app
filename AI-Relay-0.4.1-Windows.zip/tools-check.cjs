'use strict';
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), assert = require('node:assert/strict');
const dir = path.join(__dirname, 'extension');
const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
assert.equal(manifest.version, require('./package.json').version);
assert.ok(fs.existsSync(path.join(__dirname,'assets','relay-'+manifest.version+'.ico')),'Missing versioned Windows shortcut icon');
for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.js'))) {
  new vm.Script(fs.readFileSync(path.join(dir, file), 'utf8'), {filename: file});
}
const html = fs.readFileSync(path.join(dir, 'app.html'), 'utf8');
const uiScripts = [...html.matchAll(/<script src="([^"]+)"/g)].map(match => match[1]);
const contentScripts = manifest.content_scripts.flatMap(s => s.js);
for (const file of [...uiScripts, ...contentScripts, ...Object.values(manifest.icons), manifest.background.service_worker]) {
  assert.ok(fs.existsSync(path.join(dir, file)), 'Missing packaged file: ' + file);
}
assert.ok(uiScripts.indexOf('editor.js') < uiScripts.indexOf('engine.js'));
assert.ok(contentScripts.indexOf('editor.js') < contentScripts.indexOf('content.js'));
assert.ok(html.includes('Relay ' + manifest.version));
console.log('Verified extension syntax, script order, referenced files and version ' + manifest.version);
